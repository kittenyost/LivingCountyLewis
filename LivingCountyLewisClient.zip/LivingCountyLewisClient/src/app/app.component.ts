import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';  // ✅ Import HttpClient

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  imports: [CommonModule, HttpClientModule]  // ✅ Ensure HttpClientModule is included
})
export class AppComponent implements OnInit {
  users: any[] = [];  //

  constructor(private http: HttpClient) { } // ✅ Inject HttpClient

  ngOnInit() {
    this.fetchUsers();
  }

  fetchUsers() {
    this.http.get<any[]>('http://localhost:5287/api/user').subscribe({
      next: (data) => {
        this.users = data;
        console.log('Users fetched successfully:', this.users);
      },
      error: (error) => {
        console.error('Error fetching users:', error);
      }
    });
  }
}
