import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter, Routes } from '@angular/router';  // ✅ Import provideRouter for routing
import { importProvidersFrom } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app/app.component'; // ✅ Ensure this path is correct

// ✅ Define routes correctly
const routes: Routes = [
  { path: '', component: AppComponent }
];

bootstrapApplication(AppComponent, {
  providers: [
    provideRouter(routes), // ✅ Correct routing setup
    importProvidersFrom(HttpClientModule) // ✅ Ensure HttpClientModule is included
  ]
}).catch(err => console.error(err));
