export const environment = {
  production: true,
  apiUrl: 'https://your-live-api-url.com/api' // Update for production
};
