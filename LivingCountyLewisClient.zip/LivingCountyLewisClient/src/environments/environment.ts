export const environment = {
  production: false,
  apiUrl: 'http://localhost:5287/api' // Update with your API URL
};
